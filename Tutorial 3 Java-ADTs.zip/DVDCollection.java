//this class manages a collection of dvd objects
public class DVDCollection {
 //maximum num of dvds that are allowed
    public static final int     MAX_DVDS = 100;
    //this is an array to store dvds and track how many are existent
    private DVD[]   dvds;
    private int     dvdCount;
    //this constructor initializes the dvd array
    public DVDCollection() { dvds = new DVD[MAX_DVDS]; }
    //this returns the array of dvds
    public DVD[] getDvds() { return dvds; }
//this returns a copy of the current dvds in the collection
    public DVD[] getDVDArray() {
        DVD[] list = new DVD[dvdCount];
        for (int i=0; i<dvdCount; i++)
            list[i] = dvds[i];

        return list;
    }
//this returns the number of dvds
    public int getDvdCount() { return dvdCount; }
    //this returns the information about the collection
    public String toString() { return ("DVD Collection of size " + dvdCount); }
    //this adds a dvd to the collection
    public void add(DVD aDvd) {
        if (dvdCount < MAX_DVDS)
            dvds[dvdCount++] = aDvd;
    }
    //this removes a dvd by title
    public boolean remove(String title) {
        for (int i=0; i<dvdCount; i++) {
            DVD d = dvds[i];
            if (dvds[i].getTitle().equals(title)) {
                dvds[i] = dvds[dvdCount-1];
                dvdCount--;
                return true;
            }
        }
        return false;
    }
//this creates an example DVD collection
    public static DVDCollection example1() {
        DVDCollection c = new DVDCollection();
        c.add(new DVD("If I Was a Student",2007,65));
        c.add(new DVD("Don't Eat Your Pencil !", 1984, 112));
        c.add(new DVD("The Exam", 2001, 180));
        c.add(new DVD("Tutorial Thoughts", 2003, 128));
        c.add(new DVD("Fried Monitors", 1999, 94));
        return c;
    }
//this essentially removes a dvd by its index
    public void remove(int selectedIndex) {
        if(selectedIndex>= 0 && selectedIndex < dvdCount){
            dvds[selectedIndex] = dvds[dvdCount-1];
            dvdCount--;
        }
    }
}