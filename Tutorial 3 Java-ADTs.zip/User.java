import java.util.ArrayList;
import java.util.List;

public class User {
    //fields / attributes for username, online or offline, and list of songs by the user
    private String     userName;
    private boolean    online;
    private List<Song> songList;
    //this is a constructor to create a user with no songs
    public User(String u)  {
        this.userName = u;
        //the user will begin offline
        this.online = false;
        this.songList = new ArrayList<>();
    }
    //this is a constructor to create a user with existing list of songs
    public User(String u, ArrayList<Song> songList)  {
        this.userName = u;
        this.online = false;
        this.songList = songList;
    }
    //this will return the list of songs from the user
    public List<Song> getSongs()  {return songList;}
    //return's the name of the user
    public String getUserName()        { return userName; }
    //returns if they are online
    public boolean isOnline()          { return online; }
    //this is a formatted string describing the user
    public String toString()  {
        String s = "" + userName + ":"+ songList.size() + " songs (";
        if (!online) s += "not ";
        return s + "online)";
    }
    //this essentially adds a song to the list of the user
    public void addSong(Song s) {
        //if there is a owner set the user as the owner
        if(!s.hasOwner()) {s.setOwner(this);}
        songList.add(s);
    }
    //this calculates the full duration of all the songs which is owned by the user
    public int totalSongDuration(){
        int totalDuration = 0;
        for (Song s : songList){
            totalDuration += s.getDuration();
        }
        return totalDuration;
    }
    //this essentially registers the user in a MusicExchangeCenter
    public void register(MusicExchangeCenter m){
        m.registerUser(this);
    }
    //puts the user online or offiline
    public void logon() {online = true;}
    public void logoff() {online = false;}
    //this asks for a complete list of all avaliable songs from the music centre
    public List<String> requestCompleteSonglist(MusicExchangeCenter m){
       //this gets all avaliable songs from the music centre
        List<String> formattedList = new ArrayList<>();
        List<Song> songs = m.allAvailableSongs();
        //this is the header for the song list formatted
        String header = String.format("%-2s %-30s %-20s %-5s %-20s",
                "","TITLE","ARTIST","TIME","OWNER");
        formattedList.add(header);
        int count = 1;
        //this formats each song into a readable string
        for (Song s : songs){
            int minutes = s.getMinutes();
            int seconds = s.getSeconds();

            String time = String.format("%d:%02d", minutes, seconds);

            String line = String.format("%2d. %-30s %-20s %-5s %-20s",
                    count,
                    s.getTitle(),
                    s.getArtist(),
                    time,
                    s.getOwner(),getUserName());

            formattedList.add(line);
            count++;
        }
        return formattedList;
    }
    //this requests a list of songs by a specified artist
    public List<String> requestSonglistByArtist(MusicExchangeCenter m, String artist){
        List<String> formatedList = new ArrayList<>();
        //this gets the songs by the given artist from the music center
        List<Song> songs = m.availableSongsByArtist(artist);

        String header = String.format("%-2s %-30s %-20s %-5s %-20s",
                "","TITLE","ARTIST","TIME","OWNER");

        formatedList.add(header);
        int count = 1;
        //this formats each song for the display
        for (Song s : songs){
            //this gets the minutes of the song
            int minutes = s.getMinutes();
            //this gets the seconds of the song
            int seconds = s.getSeconds();
            //this formats the time as minutes/seconds
            String time = String.format("%d:%02d", minutes, seconds);
            //this forms a formatted string which contains the song information
            String line = String.format("%2d. %-30s %-20s %-5s %-20s",
                    count, //this is the number of the song in the list
                    s.getTitle(), //getting the title
                    s.getArtist(), //getting the artist of the song
                    time, //getting the time
                    s.getOwner(),getUserName()); //getting the owner of the song
            //this adds the formatted song line into the list
            formatedList.add(line);
            //increments the counter for the next song
            count++;
        }
        //this returns the formatted list of the songs
        return formatedList;
    }
//this finds and returns a song in the user's list based on the title
    public Song songWithTitle(String title){
        for (Song s : songList){
            if(s.getTitle().equalsIgnoreCase(title)){
                return s;
            }
        }
        //this will return null if the song is not there
        return null;
    }
//this downloads a song from another user by the music center
    public void downloadSong(MusicExchangeCenter m, String title, String ownerName){
        //if the song is existent it will add it to the user's song list
        Song s = m.getSong(title, ownerName);
        if(s != null) this.songList.add(s);
    }
}