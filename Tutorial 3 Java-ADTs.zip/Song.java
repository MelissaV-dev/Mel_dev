//this song class is for a song object
//which has comparable in order for songs to be compared and sorted
public class Song implements Comparable<Song>{
  //private access modifier for the song title
  private String title;
  //Artist of the song
  private String artist;
  //length of the song
  private int duration;
  //owner of the song
  private User owner;
  //this is basically a constructor to create a new song
  //provides title, artist, minutes, and seconds
  public Song(String t, String a, int m, int s)  {
    title = t;
    artist = a;
    //this essentially converts minutes and seconds into total seconds
    duration = m * 60 + s;
    owner = null; // null refers to how no one owns the song at the start
  }
  //returns the title of the song
  public String getTitle()   {return title;}
// returns the name of the artist of the song
  public String getArtist() {return artist;}
//returns the duration in seconds
  public int getDuration()  {return duration;}
//returns the duration in minutes
  public int getMinutes()   {return duration / 60;}
//returns the duration in seconds
  public int getSeconds()   {return duration % 60;}
//returns the owner of the song
  public User getOwner() { return owner; }
  //setting the owner to that specific song
  public void setOwner(User u)  {this.owner = u;}
  //checking if the song has an owner
  public boolean hasOwner() {return owner != null;}
  //formatted the song description
  public String toString()  {
    return("\"" + title + "\" by " + artist + " " + (duration / 60) + ":" + (duration%60));
  }
//the override method compares two songs by alphabetical order by the song title
  @Override
  public int compareTo(Song s) {
    return this.title.compareTo(s.getTitle());
  }
}