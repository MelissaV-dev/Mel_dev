import java.util.Scanner;

public class DVDConsoleView1 extends DVDConsoleViewBase {

    public DVDConsoleView1(Scanner in) {
        super(in);
    }

    @Override
    public String renderString(DVD[] dvds, int selectedIndex) {
        if (dvds == null || dvds.length == 0) {
            return "No DVDs in the collection.";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("DVD Collection Console View1\n");
        sb.append("---------------------------------------------\n");

        // Loop through DVDs and append each one
        for (int i = 0; i < dvds.length; i++) {
            DVD dvd = dvds[i];

            if(i== selectedIndex) {
                sb.append("-> ");
            }else {
                sb.append(" ");
            }
            sb.append(i + 1)              // number in the list
                    .append(". ")
                    .append(dvd.toString())     // DVD formatted string
                    .append("\n");
        }

        return sb.toString();
    }
}
