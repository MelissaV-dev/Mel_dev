import java.util.Scanner;
//this is a subclass of dvdconsoleviewbase that displays dvds in the console
public class DVDConsoleView2 extends DVDConsoleViewBase {
    //this constructor passes the scanner to the base class
    public DVDConsoleView2(Scanner in) {
        super(in);
    }
    //this essentially creates a string that represents the dvd list
    public String renderString(DVD[] dvds, int selectedIndex) {
        //if there is no dvds it will provide a message
        if (dvds == null || dvds.length == 0) {
            return "No DVDs in the collection.";
        }
        StringBuilder sb = new StringBuilder();
        //this is the header for the console view
        sb.append("DVD Collection Console View2\n");
        sb.append("#   Title                           Year Duration\n");
        sb.append("---- ------------------------------ ---- --------\n");
        //this will loop through the dvds and provide the display of them
        for (int i = 0; i < dvds.length; i++) {
            DVD dvd = dvds[i];
            //this marks the selected dvd
            if(i == selectedIndex) {
                sb.append("-> ");
            }else{
                sb.append("");
            }
            //this formats the dvd info
            sb.append(String.format("%-3s %-30s %4d %6s\n",
                    (i + 1) + ".",
                    dvd.getTitle(),
                    dvd.getYear(),
                    dvd.getLength() + " min"));
        }

        return sb.toString();
    }
}