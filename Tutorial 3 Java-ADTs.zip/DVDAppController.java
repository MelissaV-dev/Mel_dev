import java.io.InputStream;
import java.util.Scanner;
public class DVDAppController {
    // view used in order to display information to the user
    private DVDConsoleViewBase view;
    //model essentially stores the dvd collection
    private DVDCollection model;
    //this keeps track of the current selected dvd
    private int selectedIndex;
    //allows the user to select a dvd from the list
    private void handleSelect() {
        int dvdCount = model.getDvdCount();
        int choice = view.promptInt("Enter DVD number to select (1-" + dvdCount + "): ", 1, dvdCount);
        selectedIndex = choice - 1;
    }
    //this is a constructor
    public DVDAppController(InputStream input) {
        //add code to the constructor in the controller class to set the model to
        //DVDCollection.example1();
        this.model = model = DVDCollection.example1();
        // Create the view to consoleview1
        view = new DVDConsoleView1(new Scanner(input));
       //set first dvd as selected
        this.selectedIndex = 0;
    }
//this essentially commences the application loop
    public void start() {
        boolean running = true;
        while (running) {
            //updates the view
            view.update(model, selectedIndex);
            //displays the menu choices
            view.displayMenu();
            //get the users choice
            int choice = view.promptMenuChoice();
            switch (choice) {
                //this moves the selection up
                case 1:
                    if (selectedIndex > 0) {
                        selectedIndex--;
                    }
                    break;
                    //moves the selection downwards
                case 2:
                    if (selectedIndex < model.getDVDArray().length - 1) {
                        selectedIndex++;
                    }
                    break;
                    //plays the selected dvd
                case 3:
                    if (model.getDVDArray().length > 0) {
                        DVD selectedDVD = model.getDVDArray()[selectedIndex];
                        System.out.println("Playing DVD: " + selectedDVD.getTitle());
                    } else {
                        System.out.println("No DVDs to play. ");

                    }
                    break;
                //this exists the program
                case 0:
                    running = false;
                    System.out.println("Goodbye!");
                    break;
                //this selects a dvd
                case 5:
                    handleSelect();
                    break;
                    //adds a new dvd
                case 6:
                    handleAdd();
                    break;
                    //this deletes the selected dvd
                case 4:
                    handleDeleteSelected();
                    break;
                //this refers to an invalid menu option
                    default:
                    System.out.println("Invalid choice. Try again. ");
            }

        }
    }
    //this returns the dvd collection model
    public DVDCollection getModel() {
        return model;
    }
    //this is a main method that commences the program
    public static void main(String[] args) {
        DVDAppController app = new DVDAppController(System.in);
        app.start();
    }
    //this handles adding a new dvd
    private void handleAdd() {
        String title = view.promptString("Title: ");
        int year = view.promptInt("Year: ", 1800, 2100);
        int length = view.promptInt("Length(minutes): ", 1, 999);
        DVD newDVD = new DVD(title, year, length);
        //this adds a dvd to the collection
        model.add(newDVD);
        //selects the new dvd that was added
        selectedIndex = model.getDVDArray().length - 1;
    }
    //handles deleting the dvd that was selected
    private void handleDeleteSelected() {
if(model.getDVDArray().length>0) {
    //removing the dvd
    model.remove(selectedIndex);
    if (model.getDVDArray().length == 0) ;
    selectedIndex = 0;
} else if (selectedIndex>=model.getDVDArray().length) {
    //this adjusts the index if it is out of the range
    selectedIndex=model.getDVDArray().length-1;
}else{
    //this refers to no dvds that need to be deleted
    System.out.println("No DVDs to delete. ");
    }

    }
}

