import java.util.Scanner;
//this is an abstract base class for console views of the DVD collection
public abstract class DVDConsoleViewBase {
    //scanner used to read user input
    protected final Scanner scanner;
    //this is a constructor that receives the Scanner object
    public DVDConsoleViewBase(Scanner in) {
        this.scanner = in;
    }
//this updates the view by printing the DVD list
    public void update(DVDCollection model, int selectedIndex) {
        if (model == null) {
            //prints an empty list if there is no model
            System.out.println(renderString(new DVD[0], selectedIndex));
        } else {
            //otherwise it will display the DVDs from the model
            System.out.println(renderString(model.getDVDArray(), selectedIndex));
        }    }
    //this is a abstract method that subclasses must implement
    //this returns a formatted string of the DVD list
    public abstract String renderString(DVD[] dvds, int selectedIndex);

    //displays the menu options
    public void displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. View DVDs");
        System.out.println("2. Select DVD");
        System.out.println("3. Add DVD");
        System.out.println("4. Delete selected DVD");
        System.out.println("5. Quit");
    }
    //this is a prompt for the user to choose a menu option
    public int promptMenuChoice() {
        return promptInt("Enter your choice: ", 1, 5);
    }

    //allows the user to enter a string
    public String promptString(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }
    //this prompts the user for an integer within the range
    public int promptInt(String prompt, int min, int max) {
        while (true) {
            System.out.print(prompt);
            String s = scanner.nextLine().trim();
            try {
                int x = Integer.parseInt(s);
                //this checks if the number is in the range
                if (x < min || x > max) {
                    System.out.println("Please enter a number between " + min + " and " + max + ".");
                } else return x;
            } catch (NumberFormatException e) {
               //this checks if the input is not a valid integer
                System.out.println("Please enter a valid integer.");
            }
        }
    }
    //this displays the message to the user
    public void showMessage(String msg) {
        System.out.println(msg);
    }


}
