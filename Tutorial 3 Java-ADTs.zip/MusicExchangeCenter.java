import java.util.*;
//this class is responsible for handling users, songs, downloads, and royalties
public class MusicExchangeCenter {
    //this is a list of all the registered users
    private List<User> users;
    //this stores how much royalty each artist has received
    Map<String, Float> royalties;
    //this is for list of songs that have been downloaded
    private List<Song> downloadedSongs;
    //this is a constructor that initializes every list
    public MusicExchangeCenter(){
        users = new ArrayList<>();
        royalties = new HashMap<>();
        downloadedSongs = new ArrayList<>();
    }
    //returns the list of users
    public List<User> getUsers()                        {return users;}
    //returns the royalties map
    public Map<String,Float> getRoyalties()             {return royalties;}
    //returns the list of downloaded songs
    public List<Song> getDownloadedSongs()                        {return downloadedSongs;}
    //this provides the list of users who are online
    public List<User> onlineUsers(){
        ArrayList<User> onlineUsers = new ArrayList<>();
        //this is a for each loop.When the user is online it will add them to the OnlineUsers list.
        for (User u : users){
            if (u.isOnline()){
                onlineUsers.add(u);
            }
        }

        return onlineUsers;
    }
    //this returns all the songs that are available from user who are online
    public List<Song> allAvailableSongs(){
        List<Song> songsAvailable = new ArrayList<>();
        for (User u : onlineUsers()){
            songsAvailable.addAll(u.getSongs());
        }

        return songsAvailable;
    }
    //this returns a description of the music exchange center
    public String toString(){
        int songs = allAvailableSongs().size();
        int online =  onlineUsers().size();
        return "Music Exchange Center (" + online + " users on-line, "
                + songs + " songs available)";
    }
    //this will essentially find and return a user by their name
    public User userWithName(String s){
        for (User u : users){
            if (u.getUserName().equals(s)){
                return u;
            }
        }
        return null; //null essentially returns nothing
    }
    //this will register a new user if they aren't registered
    public void registerUser(User x){
        if(userWithName(x.getUserName()) == null){
            users.add(x);
        }
    }
    //this essentially returns all available songs by a specific artist
    public List<Song> availableSongsByArtist(String artist){
        ArrayList<Song> avalableSongs = new ArrayList<>();
        for(User u : onlineUsers()){
            for (Song s : u.getSongs())
                if (s.getArtist().equalsIgnoreCase(artist)){
                    avalableSongs.add(s);
                }
        }
        return avalableSongs;
    }
    //this lets the user download a song from another user
    public Song getSong(String title, String ownerName){
        User u = userWithName(ownerName);
        //this will check if the user exists and is currently online
        if(u != null && u.isOnline()){
            Song s = u.songWithTitle(title);
            //if the song is existing it records the download
            if(s != null){
                downloadedSongs.add(s);
                //this adds a royalty payment to the artist
                String artst = s.getArtist();
                float currTot = royalties.getOrDefault(artst, 0.0f);
                royalties.put(artst, currTot + 0.25f);
                return s;
            }
        }
        return null;
    }
    //this essentially displays how much the artists earns because of royalties
    public void displayRoyalties(){
        System.out.println(String.format("%-6s %s","Amount","Artist"));
        System.out.println("---------------");
        for (String i : royalties.keySet()){
            if (royalties.get(i) > 0){
                System.out.println(String.format("$%-5.2f %s", royalties.get(i),i));
            }
        }
    }
//this will return a set of unique songs that are downloaded
    public TreeSet<Song> uniqueDownloads(){
        TreeSet<Song> uniqueDowloads = new TreeSet<>();
        uniqueDowloads.addAll(downloadedSongs);
        return uniqueDowloads;
    }
    //this will return a list of songs sorted by the amount of times the song got downloaded
    public List<Pair<Integer, Song>> songsByPopularity(){
        //this counts the amount of times each song is downloaded
        Map<Song, Integer> counter = new HashMap<>();
        for (Song s : downloadedSongs){
            counter.put(s, counter.getOrDefault(s, 0) + 1);
        }
    //this stores the popularity list outcome
        List<Pair<Integer,Song>> popularityList = new ArrayList<>();

        for(Song s : counter.keySet()){
            popularityList.add(new Pair<Integer, Song>(counter.get(s), s));
        }
        //this sorts the songs by the amount of downloads, but it goes by highest in terms of downloads
        Collections.sort(popularityList, new Comparator<Pair<Integer, Song>>() {
            public int compare(Pair<Integer, Song> p1, Pair<Integer, Song> p2) {
                return p2.getKey().compareTo(p1.getKey());
            }}
        );

        return popularityList;
    }
}





