//laptop class that inherits from computer
public class Laptop extends Computer {
    //private access modifier and variable to store the screen size of the laptop
    private double screenSize;
    //this is a constructor to create a laptop object
    //takes all the computer attributes which includes the screen size
    public Laptop(double price, int quantity, double cpuSpeed, int ram, boolean ssd, int storage, double screenSize) {
        //this is the parent class for computer constructor
        super(price, quantity, cpuSpeed, ram, ssd, storage);
        //putting the screen size
        this.screenSize = screenSize;
    }
    //this overides the to string for the laptop details
    //this provides the formatted string with the laptop information
    @Override
    public String toString() {
        return String.format(
                "%.1f inch Laptop PC with %.1fghz CPU, %dGB RAM, %dGB %s drive.\n(%s dollars each, %d in stock, %d sold)",
                screenSize,
                getCpuSpeed(),
                getRam(),
                getStorage(),
                isSSD() ? "SSD" : "HDD",
                formatPrice(getPrice()),
                getStockQuantity(),
                getSoldQuantity()
        );
    }
}

