//The fridge class inherits from appliance
public class Fridge extends Appliance {
    //this is a boolean variable to check if the fridge  has a freezer
    private boolean hasFreezer;
    //constructor which creates a Fridge object
    //this will essentially take all appliance attributes plus the boolean hasfreezer
    public Fridge(double price, int quantity, int wattage, String colour, String brand, boolean hasFreezer){
     //this calls the parent appliance constructor
        super(price, quantity, wattage, colour, brand);
      //set whether the fridge has a freezer
     this.hasFreezer=hasFreezer;
    }
    //this overides the to string method in order to display the fridge information
    @Override
    public String toString(){
        //if the fridge has a freezer, it will implement "with freezer" to the description
        String freezer = (hasFreezer) ? "with Freezer " : "";
        //this will provide the formatted string with the fridge information
        return String.format("%s Fridge %s(%s, %d watts)\n(%s dollars each, %d in stock, %d sold)",
                getBrand(),
                freezer,
                getColour(),
                getWattage(),
                formatPrice(getPrice()),
                getStockQuantity(),
                getSoldQuantity()
        );
    }

}