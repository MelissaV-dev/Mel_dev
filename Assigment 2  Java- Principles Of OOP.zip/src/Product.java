// this is the product class that stores basic product information
public class Product {
    //price of the product
    private double price;
    //this is for the number of items that are currently in stock
    private int stockQuantity;
    //this is for the numbers of items which are sold
    private int soldQuantity;
    //this is a constructor to create a product
    public Product(double price, int stockQuantity){
        this.price = price;
        this.stockQuantity =stockQuantity;
        this.soldQuantity =0;
    }
    //this is a method to sell a certain number of units
    public double sellUnits(int amount){
        //if the amount is 0 or more than the stock a sale will not occur
        if(amount ==0 || amount > stockQuantity)
            return 0;
        //reducing the stock
        stockQuantity -= amount;
        //increasing the sold count
        soldQuantity += amount;
        //returning the amount earned
        return amount * price;
    }
    //returning the product price
    public double getPrice(){
        return price;
    }
    //return how many are in stock
    public int getStockQuantity(){
        return stockQuantity;
    }
    //returning how many have been sold
    public int getSoldQuantity(){
        return soldQuantity;
    }
    //this formats the price
    protected String formatPrice(double price) {
        if (price == Math.floor(price)) return String.format("%.1f", price);
        return String.valueOf(price);
    }
}