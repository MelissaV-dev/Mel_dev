//this is the desktop class that extends computer
public class Desktop extends Computer {
    //this stores the profile of the desktop
    private String profile;
    //this is a constructor to create a desktop object
    public Desktop (double price, int quantity, double cpuSpeed, int ram, boolean ssd, int storage, String profile){
       //calls the parent class for computer constructor
        super(price, quantity, cpuSpeed, ram, ssd, storage);
        //this is essentially setting the desktop profile
        this.profile =profile;
    }
    //this returns the desktop profile
    public String getProfile() {
        return profile;
    }
    //this displays the desktop details as a tostring and overides it
    @Override
    public String toString() {
        return String.format(
                "%s Desktop PC with %.1fghz CPU, %dGB RAM, %dGB %s drive.\n(%s dollars each, %d in stock, %d sold)",
                profile,
                getCpuSpeed(),
                getRam(),
                getStorage(),
                isSSD() ? "SSD" : "HDD",
                formatPrice(getPrice()),
                getStockQuantity(),
                getSoldQuantity()
        );
    }
}