//oven class that inherits from appliance
public class Oven extends Appliance {
    //this is a boolean variable to check if the oven has a convection
    private boolean convection;

    //this is a constructor to create an oven object
    //this constructor takes all Appliance attributes plus the boolean convection
    public Oven(double price, int quantity, int wattage, String colour, String brand, boolean convection) {
        //this calls the parent class for the appliance constructor
        super(price, quantity, wattage, colour, brand);
        //this sets the convection value
        this.convection = convection;
    }
    //this is a method that returns true if the oven has a convection
    public boolean isConvection() {
        return convection;

    }
    @Override
    public String toString() {
        String conv = (convection) ? " with convection" : "";
        return String.format("%s Oven%s (%s, %d watts)\n(%s dollars each, %d in stock, %d sold)",
                getBrand(),
                conv,
                getColour(),
                getWattage(),
                formatPrice(getPrice()),
                getStockQuantity(),
                getSoldQuantity());
    }
}