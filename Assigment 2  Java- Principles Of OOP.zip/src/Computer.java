public abstract class Computer extends Product{
    //this is all private fields
    private double cpuSpeed;
    private int ram;
    private int storage;
    private boolean ssd;
    //this is the constructor for computer
    public Computer(double price, int quantity, double cpuSpeed, int ram, boolean ssd, int storage){
        super(price,quantity);
        //this is setting the computer attributes
        this.cpuSpeed=cpuSpeed;
        this.ram=ram;
        this.ssd = ssd;
        this.storage=storage;
    } //this is all returning cpu speed, ram, storage and ssd
    public double getCpuSpeed(){
        return cpuSpeed;
    }
    public int getRam(){
        return ram;
    }
    public int getStorage(){
        return storage;
    }
    public boolean isSSD(){
        return ssd;
    }
}