//appliance is an abstract class which extends product
public abstract class Appliance extends Product {
    //this is the power usage in watts
    private int wattage;
    //this is colour in (UK)
    private String colour;
    //this is for the brand name of the appliance
    private String brand;
    //this is a constructor to create an appliance
    public Appliance(double price, int quantity, int wattage, String colour, String brand) {
        //this calls the product constructor
        super(price, quantity);
        //these are set appliance attributes
        this.colour = colour;
        this.wattage = wattage;
        this.brand = brand;
    }
    //these are all returning things like wattage, brand, and colour
    public int getWattage() {
        return wattage;
    }
    public String getBrand() {
        return brand;
    }
    public String getColour() {
        return colour;
    }
}