import java.util.Scanner;
public class ElectronicStore {
    //this is essentially the maximum number of different product instances the store can contain
    private final int MAX_PRODUCTS = 10;
    //string name which is the name of the electronic store
    private String name;
    //the total revenue the store has made by sales
    //initially set to zero , but when products are sold it needs to be updated
    private double revenue = 0;
    //array of electronic store products that is of size max products
    private Product[] products;
    //product count is initiated in order to prevent nulls that occur during the array
    private int productCount;
    //ElectronicStore (String Name) as the constructor for the class
    public ElectronicStore(String name) {
        //store sn array of electronic store products that is the size of MAX_PRODUCTS
        //creating a string called get name to return the name of the store
        this.name = name;
        this.revenue = 0.0;
        this.products = new Product[MAX_PRODUCTS];
        this.productCount = 0;
    }
    public String getName() {
        return name;
    }
    public double getRevenue() {
        return revenue;
    }
    //method for addProduct(Product p)
    public boolean addProduct(Product p) {
        if (productCount >= MAX_PRODUCTS) {
            return false;
        }
        products[productCount] = p;
        productCount++;
        return true;
    }
    //void print stock method - print out the products of the store
    public void printStock() {
        //if i is greater than the product count it will iterate
        for (int i = 0; i < productCount; i++) {
            //printing i and the product
            System.out.println(i + " " + products[i]);
        }
    }
    //sell products method
    public boolean sellProducts() {
        //scanner is used to get input
        Scanner scanner = new Scanner(System.in);
        //printing the stock
        printStock();
        //sell products sells amount units of the product stored at index item in the products array
        System.out.print("Enter a product index to sell");
        //checks if scanner is an int and if it returns a boolean
        if (!scanner.hasNextInt()) {
            //if the input is invalid it will return false
            System.out.println("Invalid input");
            return false;
        }
        //this essentially reads the index of the product in order to sell it
        int item = scanner.nextInt();
        System.out.print("Enter number of units to sell: ");
        //this checks if the user entered a valid integer for the amount
        if (!scanner.hasNextInt()) {
            //invalid if they did not give a valid int
            System.out.println("Invalid input.");
            //this stops the method since its not valid
            return false;
        }
        //this reads how many units the user would like to sell
        int amount = scanner.nextInt();
        //this calls the sellproducts method with the specific item and amount
        return sellProducts(item, amount);
    }
    //this is a method to sell a specific number of units for a product
    public boolean sellProducts(int item, int amount) {
        //this will check if the index of the product is valid
        if (item < 0 || item >= productCount || products[item] == null) {
            System.out.println("Invalid product index.");
            return false; // if invalid it returns false
        }
        //checking if the amount is higher than 0
        if (amount <= 0) {
            System.out.println("Amount needs to be greater than 0.");
            return false; //if the amount is not valid it will stop
        }
        //this will sell the units and get the revenue from the sale
        double saleRevenue = products[item].sellUnits(amount);
        //this checks if the sale did not occur due to the stock
        if (saleRevenue == 0) {
            System.out.println("sale can not be completed. There is not enough in stock. ");
            return false;
        }
        //this essentially adds the revenue to the sale revenue
        revenue += saleRevenue;
        //printing the sale affirmation
        System.out.printf("Sold %d unit(s) of: %s%nRevenue from sale: $%.2f%n", amount, products[item].getClass().getSimpleName(), saleRevenue);
        return true;

    }
}








