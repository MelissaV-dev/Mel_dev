import java.util.Scanner;
public class TaxProgram {
    public static void main(String args[]) {
        double income, fedTax, provTax;
        int dependents;
        //scanner import class for receiving input
        Scanner input = new Scanner(System.in);
        //Asking the user for the taxable income
        System.out.print("Please enter your taxable income: ");
        income = input.nextDouble();
        System.out.println();
        //Asking the user for number of dependents
        System.out.print("Please enter your number of dependents: ");
        dependents = input.nextInt();
        System.out.println();

        //initializing tax variables
        fedTax = 0.0;
        provTax = 0.0;

        //providing if statements to get the federal tax
        //This is when the income is less than or equal to $29,590

        if(income <= 29590) {
        //The federal tax needs to be 17% of the income
            fedTax=0.17*income;
        }
        //If the income is in the range from $29,590.01 to $59,179.99 then the federal tax
        //should be:(17% of $29,590 + (26% of (the income minus $29,590))

        if((income >= 29590.01 && income <= 59179.99)) {
            fedTax = 0.17 * 29590 + 0.26 * (income -29590);
        }

        //If the income is $59,180 or more then the federal tax should be:
        //(17% of $29,590) + (26% of $29,590) + (29% of (the income minus $59,180))

        if (income >=59180) {
            fedTax = (0.17 * 29590) + (0.26 * (59180-29590)) + (0.29 * (income - 59180));
        }
        //The base provincial tax
        double baseProvTax = 0.425 * fedTax;

        //the deductions for the provincial tax
        double deductions = 160.50 + 328 * dependents;

        //provTax is calculated by 0$ if the base provincial tax is less than the deductions
        if(baseProvTax> deductions){
            provTax = baseProvTax -deductions;
        }
        //total tax calculation and sum of the fedTax and provTax
        double totalTax = fedTax+provTax;


        //final output nice, organized, and formatted
        System.out.println("Income\t\t" +income);
        System.out.println(String.format("Dependents\t\t %s", dependents));
        System.out.println("-----------------------------------------");
        System.out.println(String.format("FedTax\t\t %.2f", fedTax ));
        System.out.println(String.format("ProvTax\t\t %.2f", +provTax));
        System.out.println(String.format("TotalTax\t %.2f", +totalTax));


    }
}