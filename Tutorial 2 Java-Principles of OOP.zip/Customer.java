public class Customer {
    //Providing the customer's information (name, age, money, and admission status)
    String name;
    int age;
    float money;
    boolean admitted;


    //Name constructor
    public Customer(String initName) {
        name = initName;
        age = 0;
        money = 0.0f;
        admitted=false;

    }
//providing a constructor with name and age
    public Customer(String initName, int initAge) {
        name = initName;
        age = initAge;
        admitted=false;
    }
//this is a constructor with name, age, and money
    public Customer(String initName, int initAge, float initMoney) {
        name = initName;
        age = initAge;
        money = initMoney;
        admitted=false;
    }
//this is the default constructor
    public Customer() {
    name="Unknown";
    age=-1;
    money=0.0f;
    admitted=false;

    }
//method for calculating the admission fee which is depending on the age
    public float computeFee() {
        if (age <= 3) {
            return 0.0f;

        } else if (age >= 4 && age <= 17) {
            return 8.50f;
        } else if (age >= 65) {
            return 12.75f / 2;
        } else {
            return 12.75f;
        }

    }

    //The following code is to spend money if avaliable
    public boolean spend(float amount) {
        if (money >= amount) {
            money -= amount;
            return true;
        } else {
            return false;
        }
    }

    //creating a method call hasMorMoneyThan(Customer c)
    //checking if a customer has more money than someone else
    public boolean hasMoreMoneyThan(Customer c) {
        if (this.money > c.money) {
            return true;
        } else {
            return false;
        }

        }
        //method in order to pay the admission fee
    //provding updates on the  condition based on the succesfulness of the payment
    public void payAdmission(){
        admitted=spend(computeFee());
    }
    //providing customer's info as a string format
    public String toString(){
        return "Customer: "+ name + ", Age: " + age + ", Money: $" +money+", Admitted:"+ admitted;

}
    }



