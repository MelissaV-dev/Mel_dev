public class CustomerTestProgram {
    public static void main(String args[]){
//declaration of a variable name
        Customer c;
        Customer d;
        c=new Customer("Bob");
        c.name="Bob";
        c.age=27;
        c.money=50;
        System.out.println(c.name);
        System.out.println(c.age);
        System.out.println(c.money);

        System.out.println();



        d=new Customer("Melissa");
        d.name="Melissa";
        d.age=27;
        d.money=50;
        System.out.println(d.name);
        System.out.println(d.age);
        System.out.println(d.money);

        System.out.println();
        System.out.println(d.name + " is " + d.age + " years old and has $" + d.money);


    }
}
