public class ElectronicStoreController {
    //this is the electronic store model
    private ElectronicStore store;
    //this is the shopping cart for the current user
    private Cart cart;
    //the view for displaying information and get user input
    private ElectronicStoreView view;
    //this tracks the currently selected product in the store
    private int selectedStockIndex;
    //this is a constructor which initializes the store, cart, and view
    public ElectronicStoreController(ElectronicStore store, Cart cart, ElectronicStoreView view) {
        this.store = store;
        this.cart = cart;
        this.view = view;
        selectedStockIndex = 0;
    }
    //this starts the main programs loop
    //does updates for the view and deals with user commands until they quit
    public void start() {
        // students complete
        boolean running = true;
        while (running) {
            //this updates the view with the current state of the store and cart
            view.update(store,cart, selectedStockIndex);
            //this displays menu options to the user
            view.displayMenu();
            //this gets the user's menu choice
            int choice = view.promptMenuChoice();
            //this does an execution based on the choice of the user
            switch (choice) {
                //this moves the selection to the previous product (up or to the left)
                case 1:
                    if (selectedStockIndex > 0) selectedStockIndex--;
                    break;
                //this moves the selection to the next product (down or to the right)
                case 2:
                    if (store.getStockSize() > 0) {
                        if (selectedStockIndex < store.getStockSize() - 1) {
                            selectedStockIndex++;
                            view.showMessage("Moved selection down.");
                        } else {
                            view.showMessage("You are already at the bottom of the list.");
                        }
                    } else {
                        view.showMessage("The store is currently out of stock.");
                    }
                    break;

                //this adds the current selected product to the cart
                case 3:
                    Product selected = store.getProduct(selectedStockIndex);
                    if (selected != null) {
                        cart.addProduct(selected);
                        view.showMessage("Product added to cart.");
                    } else {
                        view.showMessage("No product selected.");
                    }
                    break;
                //this removes the last product from the cart if its existent
                case 4:
                    if (cart.getItemCount() > 0) {
                        Product toRemove = cart.getItem(cart.getItemCount() - 1);
                        cart.removeProduct(toRemove);
                        view.showMessage("Remove last product from cart.");
                    } else {
                        view.showMessage("Cart is empty.");
                    }
                    break;
                    //this will complete the sale and update the store stats
                case 5:
                    store.completeSale(cart);
                    view.showMessage("Sale completed succesfully!");
                    break;
                    //this resets the cart to start a new session
                case 6:
                    cart.clear();
                    view.showMessage("store has been reset to its initial state..");
                    break;
                    //this quits the program
                case 7:
                    running = false;
                    view.showMessage("Exiting the application goodbye.!");
                    break;
            }
        }
    }
}


