import java.util.Scanner;
public class ElectronicStoreConsoleView implements ElectronicStoreView {
    //scanner to read input from the console
    private Scanner scanner;
    //this constructor initializes the input scanner
    public ElectronicStoreConsoleView() {
        scanner = new Scanner(System.in);
    }
    //updates the console display with store stock, cart contents, and store stats
    @Override
    public void update(ElectronicStore store, Cart cart, int selectedStockIndex) {
        // TODO: Display store stock, cart contents, and store statistics
        //this is the Header
        System.out.println("Watts Up Electronics");
        System.out.println("----------------------------------");
        //this retrieves the total number of completed sales from the store model
        int sales =store.getSale();
        //gets the total money earned by the store
        double revenue = store.getRevenue();
        //this calculates the average revenue per sale
        double averageSale=(sales==0) ? 0.0: revenue/sales;

        System.out.println("Sales: " + sales);
        System.out.println("Revenue: $" + store.getRevenue());
        System.out.printf("$ / Sale: $%.2f%n", averageSale);

        //checking store stats if any
        System.out.println("\n---Store Stock---");
        for (int i = 0; i < store.getStockSize(); i++) {
            Product p = store.getProduct(i);

            if (i == selectedStockIndex) {
                System.out.println("-> "+i+". "+p);
            } else {
                System.out.println("  "+i+". "+p);
            }
        }
        // Display the contents of the shopping cart
        System.out.println("\n\nCurrent Cart ($" + cart.getTotal() + "):");

        if (cart.getItemCount() == 0) {
            System.out.println("(empty)");
        } else {
            for (int i = 0; i < cart.getItemCount(); i++) {
                System.out.println("   " + cart.getItem(i));
            }
        }
        //this displays the most popular items
        System.out.println("\n\nMost Popular Items:");

        int limit = Math.min(3, store.getStockSize());
        for(int i=0; i<limit; i++){
            Product p = store.getProduct(i);
            System.out.println((i+1) + ". " + p + "(" + p.getSoldQuantity() + " sold)");
        }
    }
    //this displays the menu of actions available to the user
    @Override
    public void displayMenu() {
        System.out.println("\n--- Menu ---");
        System.out.println("1. Move selection left");
        System.out.println("2. move selection right");
        System.out.println("3. Add selected product to the cart");
        System.out.println("4. Remove last product from the cart");
        System.out.println("5. Complete Sale");
        System.out.println("6. Reset store");
        System.out.println("7. Quit");
    }
    //this prompts the user to select a menu option
    @Override
    public int promptMenuChoice() {
        while (true) {

            System.out.print("Enter choice: ");
            try {
                int choice = Integer.parseInt(scanner.nextLine());
                return choice;
            } catch (NumberFormatException e) {
                return -1;
            }
        }
    }
    //this prompts the user to enter a string value
    @Override
    public String promptString(String prompt) {
        System.out.print(prompt + ": ");
        return scanner.nextLine();
    }
    //this prompts the user to enter an integer within the specific range
    @Override
    public int promptInt(String prompt, int min, int max) {
        int value;
        while (true) {
            System.out.print(prompt + " (" + min + "-" + max + "): ");
            try {
                value = Integer.parseInt(scanner.nextLine());
                if (value >= min && value <= max) {
                    return value;
                } else {
                    System.out.println("Input needs to be between " + min + " and " + max + ".");
                }
            } catch (NumberFormatException e) {
                System.out.println("The input is invalid. Please enter a number. ");
            }
        }

    }
    //this displays a message to the user
    @Override
    public void showMessage(String message) {
        System.out.println(message);
    }
    //this will prompt the user for an int with a minimum value
    @Override
    public int promptInt(String prompt, int min) {
        int value;
        while (true) {
            System.out.print(prompt + " (Minimum " + min + "): ");
            try {
                value = Integer.parseInt(scanner.nextLine());
                if (value >= min) {
                    return value;
                } else {
                    System.out.println("Input needs to be at least " + min + ".");
                }
            } catch (NumberFormatException e) {
                System.out.println("The input is invalid. Please enter a number.");
            }
        }
    }
}

