// Represents the current customer's shopping cart.
// The cart tracks products that have been selected but not yet sold.
// It should not permanently modify the store until a sale is completed.

public class Cart {
    //Array to store products added to the cart
    private Product[] items;
    //this keeps track of how many products are currently in the cart
    private int itemCount;
    //this constructor initializes the cart
    public Cart() {
        //Maximum of 20 items in the cart
        items = new Product[20];
        itemCount = 0;
    }
    //adds a product to the cart
    public void addProduct(Product p) {
        //only add if the cart is not full
        if (itemCount < items.length) {
            items[itemCount] = p; //place product at the next available index
            itemCount++; //this increment the item count
        }
    }
   //this remove a product from the cart
    public void removeProduct(Product p) {
        //loop through all items to find the product
        for (int i = 0; i < itemCount; i++) {
            //found the product
            if (items[i].equals(p)) {
                //this shifts all items after one position to the left
                for (int j = i; j < itemCount - 1; j++) {
                    items[j] = items[j + 1];
                }
                //this clears the last item since it has been shifted
                items[itemCount - 1] = null;
                itemCount--; //this decrements the number of items in the cart
                return;//this will exit the method after removal
            }
        }
    }
    //this will return the total price of all products in the cart
    public double getTotal() {
        double total = 0;
        for (int i = 0; i < itemCount; i++) {
            total += items[i].getPrice(); //this sums up the price of each item
        }
        return total;
    }

    //returns the number of items in the cart
    public int getItemCount() {
        return itemCount;
    }

    // this returns the product at a specific index
    public Product getItem(int index) {
        //it will only return the product if the index is valid
        if (index >= 0 && index < itemCount) {
            return items[index];
        }
        //this is for an invalid index
        return null;
    }
    //this will clear items from the cart
    public void clear() {
        for (int i = 0; i < itemCount; i++) {
            items[i] = null; //this will remove each product reference
        }
        itemCount = 0; //this resets the item counter
    }
}



