import java.util.Scanner;

public class ElectronicStore {
    public final int MAX_PRODUCTS = 10; //Maximum number of products the store can have
    private int curProducts; //current number of products in stock
    private String name; //name of the store
    private Product[] stock; //Array to hold all products
    private double revenue; //total revenue received from sales
    private int Sale;
    //this initializes the store with a name and empty stock
    public ElectronicStore(String initName) {
        revenue = 0.0;
        name = initName;
        stock = new Product[MAX_PRODUCTS];
        curProducts = 0;
        Sale =0;
    }
    //this returns the store name
    public String getName() {
        return name;
    }
    //this returns the number of products currently in stock
    public int getStockSize() {
        return curProducts;
    }
    //this returns the total revenue for the store
    public double getRevenue() {
        return revenue;
    }
    //this returns a product at a specific index, but can provide null if there is an invalid index
    public Product getProduct(int index) {
        if (index >= 0 && index < curProducts) {
            return stock[index];
        }
        return null;
    }

    public int getSale() {
        return Sale;
    }

    //Adds a product and returns true if there is space in the array
    //Returns false otherwise
    public boolean addProduct(Product newProduct) {
        if (curProducts < MAX_PRODUCTS) {
            stock[curProducts] = newProduct;
            curProducts++;
            return true;
        }
        return false;
    }
//this creates a predefined store with products and adds them to the store
public static ElectronicStore createStore() {
    ElectronicStore store1 = new ElectronicStore("Watts Up Electronics");
    Desktop d1 = new Desktop(100, 10, 3.0, 16, false, 250, "Compact");
    Desktop d2 = new Desktop(200, 10, 4.0, 32, true, 500, "Server");
    Laptop l1 = new Laptop(150, 10, 2.5, 16, true, 250, 15);
    Laptop l2 = new Laptop(250, 10, 3.5, 24, true, 500, 16);
    Fridge f1 = new Fridge(500, 10, 250, "White", "Sub Zero", false);
    Fridge f2 = new Fridge(750, 10, 125, "Stainless Steel", "Sub Zero", true);
    ToasterOven t1 = new ToasterOven(25, 10, 50, "Black", "Danby", false);
    ToasterOven t2 = new ToasterOven(75, 10, 50, "Silver", "Toasty", true);
    store1.addProduct(d1);
    store1.addProduct(d2);
    store1.addProduct(l1);
    store1.addProduct(l2);
    store1.addProduct(f1);
    store1.addProduct(f2);
    store1.addProduct(t1);
    store1.addProduct(t2);
    return store1;
}
public void completeSale(Cart cart){
        //this will check if the cart is empty to prevent the process of an empty transaction
        if(cart.getItemCount()==0){
            return;
        }
        double totalSale=0.0;
        for(int i=0; i< cart.getItemCount(); i++){
            Product p = cart.getItem(i);
            //this updates the product inventory and tracks sales
            p.sellUnits(1);
            //this accumulates the total cost of the items in this transaction
            totalSale += p.getPrice();
        }
        //this concludes the transaction by updating the store record and clearing the cart
        revenue += totalSale;
        Sale++;
        cart.clear();
    }
}

