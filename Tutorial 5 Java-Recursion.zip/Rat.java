public class Rat {
    private int	row, col;

    // Move the Rat to the given position
    public void moveTo(int r, int c) {
        row = r; col = c;
    }

    public boolean canFindCheeseIn(Maze m) {
        //m.display(row, col);
        // Return true if there is cheese at the rat's (row,col) in the maze
        if (m.cheeseAt(row, col))
            return true;

        // Return false if there is a wall at the rat's (row,col) in the maze
        if (m.wallAt(row, col) || m.hasBeenVisited(row, col))
            return false;

        // Mark this location as having been visited
        m.markVisited(row, col);

        // Move up in the maze and recursively check
        moveTo(row-1, col);
        if (canFindCheeseIn(m)) {
            moveTo(row+1, col);   // Move back down before marking
            m.markUnVisited(row, col); // Unmark the visited location
            return true;
        }
        moveTo(row+1, col);   // Move back down before marking

        // Move below in the maze and recursively check
        moveTo(row+1, col);
        if (canFindCheeseIn(m)) {
            moveTo(row-1, col);   // Move back up before marking
            m.markUnVisited(row, col); // Unmark the visited location
            return true;
        }
        moveTo(row-1, col);   // Move back up before marking

        // Move left in the maze and recursively check
        moveTo(row, col-1);
        if (canFindCheeseIn(m)) {
            moveTo(row, col+1);   // Move back right before marking
            m.markUnVisited(row, col); // Unmark the visited location
            return true;
        }
        moveTo(row, col+1);   // Move back right before marking

        // Move right in the maze and recursively check
        moveTo(row, col+1);
        if (canFindCheeseIn(m)) {
            moveTo(row, col-1);   // Move back left before marking
            m.markUnVisited(row, col); // Unmark the visited location
            return true;
        }
        moveTo(row, col-1);   // Move back left before marking

        // We tried all directions and did not find the cheese, so quit
        return false;
    }

    public int freeSpaces(Maze m){
      //this stops if this cell is a wall or was visited
        if(m.wallAt(row, col)|| m.hasBeenVisited(row, col)){
            return 0;
        }
        //this mark the cell as visited
        m.markVisited(row, col);
       //this starts counting with this cell
        int count =0;
        count +=1;
        //this checks the cell above
        moveTo(row-1, col);
        count+= freeSpaces(m);
        moveTo(row-1, col);//this returns the original spot
     //this checks the cell below
    moveTo(row+1, col);
    count+= freeSpaces(m);
    moveTo(row-1, col);//returns the original spot
//check the cell to the left
moveTo(row, col -1);
count+=freeSpaces(m);
moveTo(row,col+1);
//check the cell to the right
moveTo(row, col + 1);
count+=freeSpaces(m);
moveTo(row,col-1);
//this returns the total number of free spaces
    return count;
}

        }
