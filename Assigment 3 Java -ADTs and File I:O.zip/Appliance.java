//Abstract class capturing shared state between Fridge and ToasterOven
public abstract class Appliance extends Product{
  //private access modifiers and providing variables for product details
  private int wattage;
  private String color;
  private String brand;

  //this is a constructor which provides the appliance details
  public Appliance(double initPrice, int initQuantity, int initWattage, String initColor, String initBrand){
    super(initPrice, initQuantity); //this is calling the parent product class in order to set price and quantity
    wattage = initWattage;
    color = initColor;
    brand = initBrand;
  }
  //this will get the color,brand, and wattage, but also return them
  public String getColor(){
    return color;
  }
  public String getBrand(){
    return brand;
  }
  public int getWattage(){
    return wattage;
  }
}