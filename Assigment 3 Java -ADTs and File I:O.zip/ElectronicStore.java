
import java.io.*;
import java.util.*;
//electronic store class implements serializable
public class ElectronicStore implements Serializable {
  //store name
  private String name;
  //products and quantities
  private Map<Product, Integer> stock;
  //store revenue
  private double revenue;
  //customers
  private Set<Customer> customers;
  //this is a constructor that initializes the store name, stock and customers, revenue
  public ElectronicStore(String initName) {
    name = initName;
    revenue = 0.0;
    stock = new HashMap<>();
    customers = new HashSet<>();
  }
  //this will add a costumer to the store without any duplicates
  public boolean registerCustomer(Customer c) {
    //this will add the customer
    return customers.add(c);
  }
//this adds a product to the store if it is allowed and not currently present
  public boolean addProduct(Product newProduct) {
    if (newProduct == null) return false; //this will do a null check
    if (stock.containsKey(newProduct)) return false; //this prevents duplicates
    stock.put(newProduct, newProduct.getStockQuantity()); //this will add with the current quantity
    return true;
  }
//this returns a list of all customers
  public List<Customer> getCustomers() {
    return new ArrayList<>(customers); //this converts the set to a list
  }
//this searches for products, but its also case insensitive
  public List<Product> searchProducts(String query) {
    List<Product> matches = new ArrayList<>();
    if (query == null) return matches; //this aids with null input
    String lowerQuery = query.toLowerCase();
    //this checks for each product and sees if there is a match
    for (Product p : stock.keySet()) {
      if (p.toString().toLowerCase().contains(lowerQuery)) {
        matches.add(p);
      }
    }
    //this essentially finds the products
    return matches;
  }
//this searches for products with the term "keyword" and price range
  public List<Product> searchProducts(String query, double minPrice, double maxPrice) {
    List<Product> results = searchProducts(query); //this commences with the keyword search
    //this will remove products which are outside the price range
    for (int i = results.size() - 1; i >= 0; i--) {
      double price = results.get(i).getPrice();
      boolean underMin = (minPrice >= 0) && (price < minPrice);
      boolean overMax = (maxPrice >= 0) && (price > maxPrice);
      if (underMin || overMax) {
        results.remove(i);
      }
    }
    //this selects by price
    return results;
  }
//this adds stock to a product that exists
  public boolean addStock(Product p, int amount) {
//this adds amount to the stock of product p, but only if p is in the map
    return stock.computeIfPresent(p, (k, v) -> v + amount) != null; //this adds to the stock
  }
//this sells a product and updates the stock, customer, and revenue
  public boolean sellProduct(Product p, Customer c, int amount) {
    Integer currentStock = stock.get(p);
   //this will validate the sale conditions
    if (currentStock == null || !customers.contains(c) || amount <= 0 || currentStock < amount) {
      return false;
    }
    //this will reduce stock, update the customer history, and update the revenue
    stock.put(p, currentStock - amount);
    c.addPurchase(p, amount);
    revenue += p.getPrice() * amount;
    //this is to sell the product
    return true;
  }
  //this will return the top x customers sorted by their spending
  public List<Customer> getTopXCustomers(int x) {
    if (x <= 0) return new ArrayList<>();
    List<Customer> sorted = new ArrayList<>(customers);
    Collections.sort(sorted);//this uses the compareTo method
    //this gets the top customer in a sorted order
    return new ArrayList<>(sorted.subList(0, Math.min(x, sorted.size())));
  }
//this saves the store to a file
  public boolean saveToFile(String filename) {
    try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(filename))) {
      out.writeObject(this); //this will write the object
      return true;
    } catch (IOException e) {
      e.printStackTrace();
      return false;
    }
  }
  //this will load a store from the file
  public static ElectronicStore loadFromFile(String filename) {
    try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(filename))) {
      //this will save the store
      Object obj = in.readObject(); //this will read the object
      //this will essentially load the store
      if (obj instanceof ElectronicStore) {
        return (ElectronicStore) obj; //this will cast and return
      }
    } catch (IOException | ClassNotFoundException e) {
      e.printStackTrace();
    }
    return null; //if it failed it will provide null
  }
}


















