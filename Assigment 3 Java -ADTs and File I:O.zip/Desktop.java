//Class representing a single desktop computer
public class Desktop extends Computer{
  private String towerProfile;
  //this is a constructor
  //this sets up the desktop with price,quantity,cpu speed...
  public Desktop(double initPrice, int initQuantity, double initCPUSpeed, int initRAM, boolean initSSD, int initStorage, String initProfile){
    super(initPrice, initQuantity, initCPUSpeed, initRAM, initSSD, initStorage); //this will call the computer constructor
    towerProfile = initProfile; // this will set the tower profile
  }
   //this will return a string which describes the desktop computer
  public String toString(){
    String result = towerProfile + " Desktop PC with " + getCPUSpeed() + "ghz CPU, " + getRAM() + "GB RAM, " + getStorage() + "GB ";
    if(getSSD()){
      result += "SSD drive."; //add ssd when it has one
    }else{
      result += "HDD drive."; //if not then we add hdd
    }
    //this provides the description
    return result;
  }
}