import java.io.Serializable;//this allows objects of the class to be saved to a file
import java.util.HashMap; //this is used to store key-value pairs
import java.util.Map; //this is an interface for the hashmap
//this class represents a customer who can purchase products
public class Customer implements Comparable<Customer>, Serializable {
   //this is for the customer name
    private String name;
    //this is for the total money that was spent
    private double totalSpent;
    //this is for the bought products and amounts
    private Map<Product, Integer> purchaseHistory;
//this is a constructor which sets the name and initializes the purchases
    public Customer(String name) {
        this.name = name; //assign the name to a customer
        this.totalSpent = 0.0;//total spent will commence at 0
        this.purchaseHistory = new HashMap<>(); //this creates and empty purchase history
    }
//this gets the customers name
    public String getName() { return name; }
//this is an override to string which returns the name and the total that was spent
    //this will return a string representation of the customer
    @Override
    public String toString() {
        return name + " who has spent $" + (totalSpent == (long) totalSpent
                ? String.valueOf((long) totalSpent) //this will do a long conversion if there is no decimals
                : String.valueOf(totalSpent)); //if not that there will be decimals
    }
//this adds a purchase to the customer's record
    public void addPurchase(Product p, int quantity) {
        purchaseHistory.put(p, purchaseHistory.getOrDefault(p, 0) + quantity);
        //this will update the total that was spent
        totalSpent += p.getPrice() * quantity;
    }
//this will provide the purchase history in a printed format
    public void printPurchaseHistory() {
        if (purchaseHistory.isEmpty()) {
            System.out.println("No Purchase History Available!");
            return;
        }
        for (Map.Entry<Product, Integer> entry : purchaseHistory.entrySet()) {
            System.out.println(entry.getValue() + " x " + entry.getKey());
        }
    }
    @Override
    public boolean equals(Object o) {
        //if the thing is equal to object
        //it will provide true
        if (this == o) return true;
        //if the object o is an instanceof customer it will provide false
        if (!(o instanceof Customer)) return false;
        return name.equalsIgnoreCase(((Customer) o).name); //this does a comparison by name
    }
    @Override
    //this is a method "hashcode"
    public int hashCode() {
        return name.toLowerCase().hashCode(); //this does a hash based on the name
    }

    @Override
    public int compareTo(Customer other) {
        return Double.compare(other.totalSpent, this.totalSpent); //this will sort by the amount that was spent
    }
}
