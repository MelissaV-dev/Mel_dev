import java.io.Serializable;
//this represents a product that contains price, stock, and the sold quantity
public abstract class Product implements Serializable {
   //this is the product price
    private double price;
    //this is the stock quantity
    private int stockQuantity;
    //this is the sold quantity
    private int soldQuantity;
//this constructor sets the price and the current stock
    public Product(double initPrice, int initQuantity){
        price = initPrice;
        stockQuantity = initQuantity;
    }
//this will get the current stock, soldQuantity, and the price of the product
    public int getStockQuantity(){
        return stockQuantity;
    }

    public int getSoldQuantity(){
        return soldQuantity;
    }

    public double getPrice(){
        return price;
    }

//this sells the units of the product
    public double sellUnits(int amount){
        if(amount > 0 && stockQuantity >= amount){
            stockQuantity -= amount; //this reduces the stock
            soldQuantity += amount; //will increment the sold count
            return price * amount; //this returns the total amount of the sale
        }
        return 0.0; //this means it cannot be sold
    }
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Product)) return false;
        //this will to a string comparison for the products
        return this.toString().equals(o.toString());
    }
    @Override
    public int hashCode(){
        //this is a hashcode to string return
        return this.toString().hashCode();
    }
//every product will provides its own description of each product
    @Override
    public abstract String toString();
}
