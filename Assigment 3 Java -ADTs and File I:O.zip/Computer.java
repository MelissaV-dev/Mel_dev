//Abstract class capturing shared state between Desktop and Laptop
public abstract class Computer extends Product{
  //this provides cpu, ram, ssd, and storage as variables
  private double cpuSpeed;
  private int ram;
  private boolean ssd;
  private int storage;
  //this is a constructor for computer
  public Computer(double initPrice, int initQuantity, double initCPUSpeed, int initRAM, boolean initSSD, int initStorage){
    super(initPrice, initQuantity);
    cpuSpeed = initCPUSpeed;
    ram = initRAM;
    ssd = initSSD;
    storage = initStorage;
  }
  //this is getter methods but also returning the information
  public double getCPUSpeed(){
    return cpuSpeed;
  }
  
  public int getRAM(){
    return ram;
  }
  
  public boolean getSSD(){
    return ssd;
  }
  
  public int getStorage(){
    return storage;
  }
}